<?php
/**
 * DB Settings
 *
 * @author Ali Haider
 */


		$dbhost = "techletspk.com"; 
		$dbname = "techlets_foji";
		$dbuser = "techlets_foji";
		$dbpass=  "Cheeta@91";

		$db = new mysqli($dbhost, $dbuser,$dbpass, $dbname) or die("Database error");
