<?php

	$theemail = $_SESSION['SRC_email'];
	$theid = $_SESSION['SRC_id'];
	$thename = $_SESSION['SRC_name'];
	$thepicture = $_SESSION['SRC_picture'];
	$thepost = $_SESSION['SRC_post'];
	$theadded = $_SESSION['SRC_added'];
	$bname =  basename($_SERVER['PHP_SELF']);
	$staff = "";
	$catsPage = "";
	$home = "";
	$client = "";
	$key = "";
	$deal = "";
	if($bname == "staff.php"){
		$staff = "class=\"active\"";
	}
	else if($bname == "index.php"){
		$home = "class=\"active\"";
	}
	else if($bname == "adduser.php"){
		$staff = "class=\"active\"";
	}
	else if($bname == "updateadmin.php"){
		$staff = "class=\"active\"";
	}
	else if($bname == "clients.php"){
		$client = "class=\"active\"";
	}
	else if($bname == "addclient.php"){
		$client = "class=\"active\"";
	}
	else if($bname == "updateclient.php"){
		$client = "class=\"active\"";
	}
	else if($bname == "keycontacts.php"){
		$key = "class=\"active\"";
	}
	else if($bname == "addkeycontact.php"){
		$key = "class=\"active\"";
	}
	else if($bname == "updatekeycontact.php"){
		$key = "class=\"active\"";
	}
	else if($bname == "deals.php"){
		$deal = "class=\"active\"";
	}
	else if($bname == "adddeal.php"){
		$deal = "class=\"active\"";
	}
	else if($bname == "updatedeals.php"){
		$deal = "class=\"active\"";
	}
	else if($bname == "catagories.php"){
		$catsPage = "class=\"active\"";
	}

	$sidebarNav = '';
	
	if($_SESSION['SRC_post'] === 'clerk'){
		$sidebarNav = '<li '.$home.'>
										<a href="staff.php">
										<i class="fa fa-home"></i> <span>Home</span>
										</a>
									</li>
									
									<li '.$catsPage.'>
										<a href="catagories.php">
										<i class="fa fa-home"></i> <span>Categories</span>
										</a>
									</li>';

	} else if($_SESSION['SRC_post'] === 'admin'){
		$sidebarNav = '<li '.$home.'>
										<a href="adminhome.php">
										<i class="fa fa-home"></i> <span>Home</span>
										</a>
									</li>';
	} else if($_SESSION['SRC_post'] === 'superadmin'){
		$sidebarNav = '<li '.$home.'>
											<a href="superadminhome.php">
											<i class="fa fa-home"></i> <span>Home</span>
											</a>
										</li>';
	}

	$sidebar = '<aside class="main-sidebar">
				<!-- sidebar: style can be found in sidebar.less -->
				<section class="sidebar">
				  <!-- Sidebar user panel -->
				  <div class="user-panel">
					<div class="pull-left image">
					  <img src="'.$thepicture.'" class="img-circle" alt="User Image">
					</div>
					<div class="pull-left info">
					  <p>'.$thename.'</p>
					  <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
					</div>
				  </div>
				  <!-- sidebar menu: : style can be found in sidebar.less -->
				  <ul class="sidebar-menu">
					<li class="header">MAIN NAVIGATION</li>
					'.$sidebarNav.'
				  </ul>
				</section>
				<!-- /.sidebar -->
				</aside>';
				
	echo $sidebar;