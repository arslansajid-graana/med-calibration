<?php

 
$footer = '<footer class="main-footer">
				<div class="pull-right hidden-xs">
				 
				</div>
				<strong>Copyright &copy; 2015-2017 <a href="#">Army Inventory Management</a>.</strong> All rights
				reserved.
			  </footer>';

echo $footer;