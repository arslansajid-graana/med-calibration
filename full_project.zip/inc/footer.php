<?php

 
$footer = "<nav class=\"navbar navbar-inverse navbar-fixed-bottom\" role=\"navigation\" style=\"background:#3c8dbc; border-color:#3c8dbc; min-height: 23px; color:rgba(255,255,255,0.6); font-size:11px; padding-top:3px; \">
  <div class=\"container\" >
   <span class=\"pull-left\">
   InventoryManagement
   </span>
   <span class=\"pull-right\">
&copy; Copyrights 2016
   </span>
  </div>
</nav>";

echo $footer;